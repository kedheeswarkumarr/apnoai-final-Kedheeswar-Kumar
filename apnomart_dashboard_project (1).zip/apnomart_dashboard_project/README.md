# ApnoMart Q2 2026 Executive Dashboard

**Tool selected:** Python + Streamlit + Plotly (one committed tool stack).

## Files
- `dashboard.png` — high-resolution dashboard screenshot for submission
- `insights.pdf` — three data-backed insights and a strategic recommendation
- `app.py` — interactive dashboard source with Region, Category and Date filters
- `apnomart-sales-data.csv` — data file required by the app
- `requirements.txt` — Python dependencies

## Run the interactive dashboard
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Run `pip install -r requirements.txt`
4. Run `streamlit run app.py`
5. Open the local URL shown in the terminal.

## Main findings
- Total sales (available Q2 slice): ₹5,338,674.40
- Total profit: ₹1,374,060.32
- Orders: 383
- Weighted profit margin: 25.74%
- Revenue leader: Clothing
- Profit leader: South region

## Important data limitation
The dataset contains 1,200 orders across 2026, but the Q2 filter returns only 383 records dated May 1–June 30. No April records were present, so the analysis is explicitly labelled as the available May–June slice rather than a complete April–June quarter.

## GitHub submission checklist
1. Create a repository named `apnoai-final-yourname`.
2. Upload the files in this project folder.
3. Paste the repository URL into the task submission.
4. Notes: `Tool: Python + Streamlit + Plotly. Top insight: Clothing is the largest revenue category; South is the most profitable region in the available Q2 data.`
5. AI usage: `Used ChatGPT to help structure the dashboard and refine data-backed strategic insights.`
